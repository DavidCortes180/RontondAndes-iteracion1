package rest;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import tm.Master;
import vos.Cliente;
import vos.Ingrediente;
import vos.Menu;
import vos.Producto;
import vos.Usuario;

@javax.ws.rs.Path("restauranteServices")
public class RestauranteServices {
	@Context
	private ServletContext context;

	private String getPath() 
	{
		return context.getRealPath("WEB-INF/ConnectionData");
	}
	
	private String doErrorMessage(Exception e){
		return "{ \"ERROR\": \""+ e.getMessage() + "\"}" ;
	}
	//RF4
	@POST
	@Path("/restaurante/agregarproducto")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarProducto(Producto producto)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarProducto(producto);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(producto).build();
	}
	//RF5
		@POST
		@Path("/restaurante/agregaringrediente")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarIngrediente(Ingrediente ingrediente)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarIngrediente(ingrediente);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(ingrediente).build();
		}
	//RF6
		@POST
		@Path("/restaurante/agregarmenu")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarMenu(Menu menu)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarMenu(menu);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(menu).build();
		}
	//RF10
		@POST
		@Path("/restaurante/agregarservicioproducto")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarServicioProducto(Producto producto)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarServicioProducto(producto);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(producto	).build();
		}
}

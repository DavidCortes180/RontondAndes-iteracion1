package rest;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import tm.Master;
import vos.Cliente;
import vos.Orden;
import vos.Usuario;

@javax.ws.rs.Path("clienteServices")
public class ClienteServices {
	@Context
	private ServletContext context;

	private String getPath() 
	{
		return context.getRealPath("WEB-INF/ConnectionData");
	}
	
	private String doErrorMessage(Exception e){
		return "{ \"ERROR\": \""+ e.getMessage() + "\"}" ;
	}
	//RF8
	@POST
	@Path("/cliente/agregarpreferencia")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarPreferencia(Cliente cliente)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarPreferenciaCliente(cliente);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(cliente).build();
	}
	//RF9
		@POST
		@Path("/cliente/agregarpedido")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarPedido(Orden pOrden)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarPedidoProducto(pOrden);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(pOrden).build();
		}
}

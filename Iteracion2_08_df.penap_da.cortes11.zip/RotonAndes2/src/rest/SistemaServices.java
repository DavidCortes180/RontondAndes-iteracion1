package rest;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import tm.Master;
import vos.Cliente;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.Zona;

@javax.ws.rs.Path("sistemaServices")
public class SistemaServices {
	@Context
	private ServletContext context;

	private String getPath() 
	{
		return context.getRealPath("WEB-INF/ConnectionData");
	}
	
	private String doErrorMessage(Exception e){
		return "{ \"ERROR\": \""+ e.getMessage() + "\"}" ;
	}
	//RF1
		@POST
		@Path("/sistema/agregarUsuario")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarCliente(Usuario pUsuario)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarUsuario(pUsuario);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(pUsuario).build();
		}
	//RFC1
	@GET
	@Path("/sistema/darProductos/{idProducto: \\d+}")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarProductos(@javax.ws.rs.PathParam("idProducto") Integer idProducto)
		{
			Master mas = Master.darInstancia(getPath());
			ArrayList<Producto> productos = null;
			try
			{
				productos = mas.consultarProductosServidosEnRotonAndes(idProducto);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(productos).build();
		}
	//RFC2
	@GET
	@Path("/sistema/darZona/{idZona: \\d+}")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarZona(@javax.ws.rs.PathParam("idZona") Integer idZona)
		{
			Master mas = Master.darInstancia(getPath());
			Zona zona = null;
			try
			{
				zona = mas.consultarZona(idZona);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(zona).build();
		}
	//RFC3
	@GET
	@Path("/sistema/darClientes/{idCliente: \\d+}")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarClientes(@javax.ws.rs.PathParam("idCliente") Integer idCliente)
		{
			Master mas = Master.darInstancia(getPath());
			ArrayList<Cliente> clientes = null;
			try
			{
				clientes = mas.consultarClientes(idCliente);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(clientes).build();
		}
	//RFC4
	@GET
	@Path("/sistema/darProductosMasOfrecidos/")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response productosMasOfrecidos()
		{
			Master mas = Master.darInstancia(getPath());
			ArrayList<Producto> productos = null;
			try
			{
				productos = mas.productosMasOfrecidos();
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(productos).build();
		}
	//RFC5
	@GET
	@Path("/sistema/darRentabilidadRestaurante/{idRestaurante: \\d+}")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarRentabilidadRestaurante(@javax.ws.rs.PathParam("idRestaurante") Integer idRestaurante)
		{
			Master mas = Master.darInstancia(getPath());
			ArrayList<Restaurante> restaurantes = null;
			try
			{
				restaurantes = mas.consultarRentabilidadRestaurante(idRestaurante);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(restaurantes).build();
		}
	//RFC6
	@GET
	@Path("/sistema/darProductosMasVendidos/")
	@Produces({ MediaType.APPLICATION_JSON })
		public Response productosMasVendidos()
		{
			Master mas = Master.darInstancia(getPath());
			ArrayList<Producto> productos = null;
			try
			{
				productos = mas.productosMasvendidos();
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(productos).build();
		}
}

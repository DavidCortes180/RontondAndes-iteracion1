package vos;

import java.util.ArrayList;

public class TipoProducto {


	public static String ENTRADA = "Entrada";
	public static String PLATOFUERTE = "Plato Fuerte";
	public static String ACOMPANAMIENTOS = "Acompanamientos";
	public static String BEBIDAS = "Bebidas";
	public static String POSTRES = "Postres";
	private String contenido;
	private boolean estaModificado;
	private ArrayList<Producto> productos;

	public TipoProducto(String contenido, boolean estaModificado, ArrayList<Producto> productos) {
		super();
		this.setContenido(contenido);
		this.setEstaModificado(estaModificado);
		this.setProductos(productos);
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public boolean isEstaModificado() {
		return estaModificado;
	}

	public void setEstaModificado(boolean estaModificado) {
		this.estaModificado = estaModificado;
	}

	public ArrayList<Producto> getProductos() {
		return productos;
	}

	public void setProductos(ArrayList<Producto> productos) {
		this.productos = productos;
	}



}

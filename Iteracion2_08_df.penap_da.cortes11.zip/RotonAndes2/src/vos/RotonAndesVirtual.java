package vos;

import java.util.ArrayList;

public class RotonAndesVirtual {

	private Usuario user;
	private ArrayList<Cliente> clientes;
	private ArrayList<Restaurante> restaurantes;
	
	public RotonAndesVirtual( Usuario pUser, ArrayList<Cliente> clientes,
			ArrayList<Restaurante> restaurantes) {
		super();
		this.setUser(pUser);
		this.setClientes(clientes);
		this.setRestaurantes(restaurantes);
	}

	public ArrayList<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(ArrayList<Cliente> clientes) {
		this.clientes = clientes;
	}

	public Usuario getUser() {
		return user;
	}

	public void setUser(Usuario user) {
		this.user = user;
	}

	public ArrayList<Restaurante> getRestaurantes() {
		return restaurantes;
	}

	public void setRestaurantes(ArrayList<Restaurante> restaurantes) {
		this.restaurantes = restaurantes;
	}
	
	

}

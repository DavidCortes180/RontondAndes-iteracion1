package vos;

import java.util.ArrayList;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonProperty;

public class Orden {
private int idOrden;
private double precioTotal;
private int idMesa;
private int idusuario;
private String nombreCliente;
private Cliente cliente;
private Pago pago;
private ArrayList<Integer> idMenu= new ArrayList<Integer>();
private Date fecha;
private int hora;

public Orden(@JsonProperty(value="idOrden")int idOrden, @JsonProperty(value="precioTotal")double precioTotal,@JsonProperty(value="idMesa") int idMesa,
		@JsonProperty(value="idUsuario")int idusuario,@JsonProperty(value="nombreCliente")String nombreCliente,
		@JsonProperty(value="cliente")Cliente cliente, @JsonProperty(value="pago")Pago pago,@JsonProperty(value="fecha")Date pFecha
		, @JsonProperty(value="hora")int pHora) {
	super();
	this.setIdOrden(idOrden);
	this.setPrecioTotal(precioTotal);
	this.setIdMesa(idMesa);
	this.setIdusuario(idusuario);
	this.setNombreCliente(nombreCliente);
	this.setCliente(cliente);
	this.setPago(pago);
	this.setFecha(pFecha);
	this.setHora(pHora);
	
}
public int getIdOrden() {
	return idOrden;
}
public void setIdOrden(int idOrden) {
	this.idOrden = idOrden;
}
public double getPrecioTotal() {
	return precioTotal;
}
public void setPrecioTotal(double precioTotal) {
	this.precioTotal = precioTotal;
}
public int getIdMesa() {
	return idMesa;
}
public void setIdMesa(int idMesa) {
	this.idMesa = idMesa;
}
public int getIdusuario() {
	return idusuario;
}
public void setIdusuario(int idusuario) {
	this.idusuario = idusuario;
}
public String getNombreCliente() {
	return nombreCliente;
}
public void setNombreCliente(String nombreCliente) {
	this.nombreCliente = nombreCliente;
}
public Cliente getCliente() {
	return cliente;
}
public void setCliente(Cliente cliente) {
	this.cliente = cliente;
}
public Pago getPago() {
	return pago;
}
public void setPago(Pago pago) {
	this.pago = pago;
}
public ArrayList<Integer> getMenu() {
	return idMenu;
}
public void setMenu(ArrayList<Integer> menu) {
	this.idMenu = menu;
}
public Date getFecha() {
	return fecha;
}
public void setFecha(Date fecha) {
	this.fecha = fecha;
}
public int getHora() {
	return hora;
}
public void setHora(int hora) {
	this.hora = hora;
}


}

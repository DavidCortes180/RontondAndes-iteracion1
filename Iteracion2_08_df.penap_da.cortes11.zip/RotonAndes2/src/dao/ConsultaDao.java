package dao;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Properties;
import java.util.function.Function;

import vos.Cliente;
import vos.Ingrediente;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.Zona;


public class ConsultaDao 
{

	private Connection conexion;
	
	private String user;
	
	private String password;
	
	private String url;
	
	private String driver;
	
//	Format formatoFecha= SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	
	public ConsultaDao(String connectionData) 
	{
		// TODO Auto-generated constructor stub
		inicializarConnectionData(connectionData);
	}
	
	public Connection getConexion() {
		return conexion;
	}
	
	private void inicializarConnectionData(String conectionData)
	{
		try 
		{
			File archivo= new File(conectionData);
			Properties propertie= new Properties();
			FileInputStream input= new FileInputStream(archivo);
			propertie.load(input);
			input.close();
			this.url= propertie.getProperty("url");
			this.user = propertie.getProperty("usuario");
			this.password = propertie.getProperty("clave");
			this.driver = propertie.getProperty("driver");
			Class.forName(driver);
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private void establecerConexion() throws SQLException
	{
		System.out.println("Connecting to: " + url + " With user: " + user);
		conexion = DriverManager.getConnection(url, user, password);
	}
	
	public void cerrarConnection(Connection connection) throws SQLException
	{
		try 
		{
			connection.close();
			connection= null;
			
		} catch (SQLException e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in closing Connection:");
			e.printStackTrace();
			throw e;
		}
	}

	
	//Requerimientos
	
	
	//funcionales
	
	//RF1- Registrar Usuario
	public void registrarUsuario(Usuario pUsuario)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try
		{
			System.out.println(pUsuario);
			establecerConexion();
			String sql = "INSERT INTO USUARIO(IDUSUARIO, NOMBRE, CORREO, ROL)"+
					"VALUES("+pUsuario.getIdentificacion()+",'"+pUsuario.getNombre()+"','"+
					pUsuario.getCorreo()+"',"+pUsuario.getRol()+")";
			System.out.println(sql);
			prepStmt= conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e)
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally
		{
			if (prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RF2- Registrar Cliente
		public void registrarCliente(Cliente cliente) throws Exception
		{
			
			PreparedStatement prepStmt = null;
			try
			{
				System.out.println(cliente);
				establecerConexion();
				String sql = "INSERT INTO CLIENTE(IDCLIENTE, NOMBRE)"+
						"VALUES("+cliente.getIdCliente()+","+cliente.getNombre()+")";
				System.out.println(sql);
				prepStmt= conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e)
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
			}
			finally
			{
				if (prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
					}
				}
				
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
				
			}
		}
	//Rf3  Registrar Restaurante 
	
		public void registrarRestaurante(Restaurante restaurant)throws Exception
		{
			
				PreparedStatement prepStmt= null;

				try 
				{
					System.out.println(restaurant);
					establecerConexion();
					String sql= "INSERT INTO RESTAURANTE(IDRESTAURANTE,NOMBRE,NOMBREREPRESENTANTE,TIPOCOMIDA,ZONA)"
							+ "VALUES("+ restaurant.getIdRestaurante()+",'"+
							restaurant.getNombre()+"','"+restaurant.getNombreRepresentante()+"','"
							+restaurant.getTipoComida()+"','"+restaurant.getZona()+")";

					System.out.println(sql);
					prepStmt=conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
						} catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}

					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}

			}
		
	// RF4 Registrar Producto
		public void registrarProducto(Producto producto) throws Exception
		{
			
				PreparedStatement prepStmt = null;
				int personalisadoTraduccion;
				if(producto.isEstaPersonalizado()==true)
				{
					personalisadoTraduccion = 1;
				}
				else
				{
					personalisadoTraduccion = 0;
				}
				try 
				{
					
					System.out.println(producto);
					establecerConexion();
					String sql = "INSERT INTO PRODUCTO(IDPRODUCTO,PRECIO,ESTAPERSONALIZADO)"
							+"VALUES("+producto.getIdProducto()+","+producto.getPrecioProducto()
							+","+personalisadoTraduccion+")";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
							
						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
		
	// RF5 Registrar ingrediente
	
		public void registrarIngrediente(Ingrediente pIngredinte)throws Exception
		{
		  
				PreparedStatement prepStmt = null;

				try 
				{
					System.out.println(pIngredinte);
					establecerConexion();
					String sql = "INSERT INTO INGREDIENTE(IDINGREDIENTE,NOMBRE,DESCRIPCION,TRADUCCION)"
							+"VALUES("+pIngredinte.getIdIngrediente()+"','"+pIngredinte.getNombreIngrediente()
							+"','"+pIngredinte.getDescripcion()+"','"+pIngredinte.getTraduccion()+"')";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();

						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
		
	//RF6 Registrar Menu
		public void registrarMenu(vos.Menu menu)throws Exception
		{
			
				PreparedStatement prepStmt = null;
				int personalisadoTraduccion;
				if(menu.isEstaPersonalisado()==true)
				{
					personalisadoTraduccion = 1;
				}
				else
				{
					personalisadoTraduccion = 0;
				}
				try 
				{
					
					System.out.println(menu);
					establecerConexion();
					
					String sql = "INSERT INTO MENU(IDMENU,NOMBRE,PRECIO,ESTAPERSONALISADO,IDRESTAURENTE)"
							+"VALUES("+menu.getIdMenu()+","+menu.getNombre()
							+","+menu.getPrecio()+","+personalisadoTraduccion
							+menu.getIdRestaurante()+")";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
							
						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
		
		}
	//RF7 Registrar zona
	
	public void registrarZona(Zona pZona)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try 
		{
			System.out.println(pZona);
			establecerConexion();
			String sql = "INSERT INTO ZONA(NUMEROZONA,CAPACIDAD,ABIERTO,APTO,DESCRIPCION)"
					+"VALUES("+pZona.getNumeroZona()+"','"+pZona.getCapacidad()
					+"','"+pZona.getAbierto()+"','"+pZona.getApto()+"','"+pZona.getDescripcion()+"')";
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally {
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RF8 Registrar Preferencia Del Cliente
	public void registrarPreferencia(Cliente cliente)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try 
		{
			System.out.println(cliente);
			establecerConexion();
			String nuevaPreferencia = cliente.getPreferencia();
			String sql = "UPDATE CLIENTE SET PREFERENCIA="+nuevaPreferencia+"WHERE IDCLIENTE ="+cliente.getIdCliente();
					
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally {
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
// R9 REGISTRAR PEDIDO DE UN PRODUCTO
	
	public void registrarPedidoDeUnProducto(Orden pOrden)throws Exception
	{
		PreparedStatement prepStmt=null;
		
		try 
		{
			System.out.println(pOrden);
			establecerConexion();
			Format formatofecha= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date fecha= (Date) pOrden.getFecha();
			String fechaMeter = formatofecha.format(fecha);
			String sql= "INSERT INTO ORDEN(IDORDEN,PRECIOTOTAL,IDMESA,IDUSUARIO,NOMBRECLIENTE,FECHA,HORA)"
					+"VALUES("+pOrden.getIdOrden()+"','"+pOrden.getPrecioTotal()+"','"+pOrden.getIdMesa()
					+"','"+pOrden.getIdusuario()+"','"+pOrden.getNombreCliente()+"','"+", TO DATE ("+fechaMeter+
					" ,yyyy-MM-dd hh:mm:ss),"+"','"+pOrden.getHora()+"')";
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e)
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally
		{
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//R10 RESGISTRAR EL SERVICIO DE UN PRODUCTO
	
		public void registrarServicioDeUnProducto(Producto producto)throws Exception
		{
			PreparedStatement prepStmt=null;
			try
			{
				int idProducto = producto.getIdProducto();
				establecerConexion();
				String sql="SELECT DISPONIBLE FROM PRODUCTOS WHERE IDPRODUCTO="+idProducto;
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				int disponibleActual = rs.getInt(1);
				sql = "UPDATE PRODUCTOS SET DISPONIBLE="+(disponibleActual-1)+"WHERE IDPRODUCTO="+idProducto;
				prepStmt.close();
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			}
			catch(Exception e)
			{
				System.err.println("SQLException in executing:");
				e.printStackTrace();
			}
			finally
			{
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
						
					}
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
					}
				}
				if(this.conexion!=null)
				{
					cerrarConnection(this.conexion);
				}
			}
		}
		
	
	//Requerimientos de consulta
	
	//RFC1 CONSULTAR LOS PRODUCTOS SERVIDOS EN ROTONDANDES 
	
	public ArrayList<Producto> consultarProductosServidosEnRotonAndes(Integer IdProducto)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try
		{
			
			establecerConexion();
			String sql="SELECT * FROM PRODUCTO WHERE IDPRODUCTO="+IdProducto;
			
			prepStmt= conexion.prepareStatement(sql);
			
			ResultSet rs= prepStmt.executeQuery();
			
			ArrayList<Producto> productos= new ArrayList<Producto>();
			
			while(rs.next())
			{	
				Producto prod= new Producto(rs.getInt("IDPRODUCTO"),rs.getString("NOMBRE"), rs.getDouble("PRECIOPRODUCTO"),
						rs.getDouble("COSTOPRODUCTO"), rs.getString("DESCRIPESP"), rs.getString("DESCRIPING"), rs.getInt("TIEMPOPREPARACION")
						, rs.getBoolean("ESTAPERSONALIZADO"), rs.getString("TIPOPRODUCTO"), rs.getInt("DISPONIBILIDAD"), rs.getInt("UNIDADESVENDIDAS"));
				productos.add(prod);
				
			}
			System.out.println(productos.isEmpty());
			return productos;
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("QLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RFC2 	CONSULTAR UNA ZONA
		public Zona consultarZona(Integer numeroZona)throws Exception
		{
			Zona zona = null;
			PreparedStatement prepStmt= null;
			try
			{
				establecerConexion();
				String sql="SELECT * FROM ZONA WHERE IDZONA="+numeroZona;
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				while(rs.next())
				{
					zona = new Zona(numeroZona, numeroZona, false, false, sql);
					zona.setNumeroZona(rs.getInt(1));
					zona.setCapacidad(rs.getInt(2));
					zona.setAbierto(intABoolean(rs.getInt(3)));
					zona.setApto(intABoolean(rs.getInt(3)));
					zona.setDescripcion(rs.getString(4));
				}
				
				return zona;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("QLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}

		}
		private boolean intABoolean(int pasar)
		{
			if(pasar==1)
			{
				return true;
			}
			else
				return false;
		}
//RFC3 CONSULTAR LOS CLIENTES	
	public ArrayList<Cliente> consultarClientes(Integer idCliente)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try {
			establecerConexion();
			String sql= "SELECT * FROM CLIENTE WHERE IDCLIENTE="+idCliente;
			prepStmt= conexion.prepareStatement(sql);
			ResultSet rs= prepStmt.executeQuery();
			ArrayList<Cliente> clientes= new ArrayList<Cliente>();
			while(rs.next())
			{
				Cliente cl= new Cliente(rs.getString("NOMBRE"),rs.getInt("IDCLIENTE"),rs.getString("PREFERENCIA"));
				clientes.add(cl);
			}
			
			return clientes;
		} 
		catch (SQLException e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
		

	}
	//RFC4 OBTENER LOS PRODUCTOS MAS OFRECIDOS
		public ArrayList<Producto> productosMasOfrecidos()throws Exception
		{
	PreparedStatement prepStmt= null;
			
			try {
				establecerConexion();
				String sql= "SELECT * FROM PRODUCTO WHERE IDPRODCUTO=(SELECT IDPRODUCTO FROM MENU "
						+ "GROUP BY IDPRODUCTO HAVING COUNT(IDPRODUCTO)=(SELECT MAX(TOTAL) FROM"
						+ "(SELECT COUNT(IDPRODUCTO) AS TOTAL FROM MENU GROUP BY IDPRODUCTO)))";
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				ArrayList<Producto> productos= new ArrayList<Producto>();
				while(rs.next())
				{
					Producto producto = new Producto(rs.getInt(1), rs.getString(2), rs.getDouble(3), 
							rs.getDouble(4), rs.getString(5), rs.getString(6), rs.getInt(7), intABoolean(rs.getInt(8)),
							rs.getString(9), rs.getInt(10), rs.getInt(11));
					productos.add(producto);
				}
				
				return productos;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}
			
		}
//RFC5 CONSULTAR RENTABILIDAD DE UN RESTAURANTE
	
	public ArrayList<Restaurante> consultarRentabilidadRestaurante(Integer idRestaurante)throws Exception
	{
		PreparedStatement prepStmt=null;
		int numProdVendidos=0;
		int costoTotal=0;
		int valorFacturado=0;
		
		try 
		{
			establecerConexion();
			String sql = "SELECT * FROM RESTAURANTE WHERE IDRESTAURANTE="+idRestaurante;
			prepStmt= conexion.prepareStatement(sql);
			ResultSet rs=prepStmt.executeQuery();
			ArrayList<Restaurante> restaurantes= new ArrayList<Restaurante>();
			while(rs.next())
			{	
				Restaurante res= new Restaurante(rs.getString("NOMBRE"), rs.getInt("IDRESTAURANTE"),
						rs.getString("NOMBREREPRESENTANTE"), rs.getString("TIPOCOMIDA"));
				numProdVendidos+= rs.getInt("NUMPRODUCTOSVENDIDOS");

				
				restaurantes.add(res);
			}
			return restaurantes;
		} 
		catch (SQLException e) {
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RFC6 OBTENER LOS DATOS DE LOS PRODUCTOS MAÌ�S VENDIDOS
		public ArrayList<Producto> productosMasvendidos()throws Exception
		{
			PreparedStatement prepStmt= null;
			
			try {
				establecerConexion();
				String sql= "SELECT * FROM PRODUCTO WHERE IDPRODCUTO=(SELECT IDPRODUCTO FROM PRODUCTO "
						+ "WHERE COUNT(UNIDADESVENDIDAS)=(SELECT MAX(TOTAL) FROM"
						+ "(SELECT COUNT(UNIDADESVENDIDAS) AS TOTAL FROM PRODUCTO )))";
				prepStmt = conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				ArrayList<Producto> productos= new ArrayList<Producto>();
				while(rs.next())
				{
					Producto producto = new Producto(rs.getInt(1), rs.getString(2), rs.getDouble(3), 
							rs.getDouble(4), rs.getString(5), rs.getString(6), rs.getInt(7), intABoolean(rs.getInt(8)),
							rs.getString(9), rs.getInt(10), rs.getInt(11));
					productos.add(producto);
				}
				
				return productos;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}
		}
		
	
}
